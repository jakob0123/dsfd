﻿using System;
using System.Collections.Generic;

namespace Beispiel2
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, int> keyValue = new Dictionary<string, int>();
            keyValue.Add("Jakob Prem", 1);
            keyValue.Add("Thomas Riegler", 100);

            Console.WriteLine("Schlüssel: Jakob Prem, Wert: " + keyValue["Jakob Prem"]);
            Console.WriteLine("Schlüssel: Thomas Riegler, Wert: " + keyValue["Thomas Riegler"]);

        }
    }
}
