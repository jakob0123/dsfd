﻿using System;

namespace Beispiel1
{
    class Program
    {
        static void Main(string[] args)
        {
            string a = Beispielklasse.generateRandomString(10);
            string b = Beispielklasse.generateRandomString(20);
            string c = Beispielklasse.generateRandomString(100);
            Console.WriteLine(a);
            Console.WriteLine(b);
            Console.WriteLine(c);

            try
            {
                string negativ = Beispielklasse.generateRandomString(-5);

            }
            catch(ArgumentOutOfRangeException)
            {
                Console.WriteLine("Negative Laenge nicht moeglich");
            }


            Console.WriteLine("Vorkommen Buchstabe b in string a: " + Beispielklasse.countChar(a, 'b'));



        }
    }
}
