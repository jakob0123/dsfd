#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h> 
#include <stdlib.h>
#include <time.h>


void mischen(int* ar) {
	srand(time(NULL));

	for (int i = 0; i < 20; i++) {
		int r = rand();
		int zufallszahl = r % 7;
		int num = ar[0];
		ar[0] = ar[zufallszahl];
		ar[zufallszahl] = num;
	}

}

void main() {
	int ar[7] = { 1,2,3,4,5,6,7 };
	mischen(ar);

	for (int i = 0; i < 7; i++) {
	printf("%i",ar[i]);
	}
}

