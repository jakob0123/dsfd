﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace _2._2_Laengenanalyse
{
    class LengthCount
    {
        private Dictionary<int, int> myWordLength;
        //hätte auch mit static gemacht werden können
        public LengthCount()
        {

        }

        
        public void AnalyseWords(string text)
        {
            this.myWordLength = new Dictionary<int, int>();
            string[] words = text.Split(" ");

            

            foreach(string word in words)
            {
                if (this.myWordLength.ContainsKey(word.Length))
                {
                    this.myWordLength[word.Length]++;
                }
                else
                {
                    this.myWordLength.Add(word.Length, 1);
                }
            }
        }

        public void AnalyseWordOfFile(string pathToFile)
        {
            string text = File.ReadAllText(pathToFile);
            this.AnalyseWords(text);
        }
        public override string ToString()
        {
            foreach(KeyValuePair<int, int> element in this.myWordLength)
            {
                Console.WriteLine("{0} - {1}", element.Key.ToString(), element.Value.ToString());
            }
            return "";
        }
    }
}
