﻿using System;
using System.Collections.Generic;

namespace _2._2_Laengenanalyse
{
    class Program
    {
        static void Main(string[] args)
        {
            LengthCount count = new LengthCount();
            //Test der Methode AnalyseWords
            //count.AnalyseWords("Wie geht es dir");
            //count.ToString();
            //Console.WriteLine("---------------------------------------------------------------------");
            //Test der Methode AnalyseWordOfFile
            count.AnalyseWordOfFile(@"C:\Users\raphael.voelker\source\repos\2022_SEW3_voelker\22_SEW_voelker\2.2_Laengenanalyse\Beispieltext.txt"); //beim korrigieren bitte den richitgen PFad eingeben
            count.ToString();
        }
    }
}
