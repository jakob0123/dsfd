﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _2._1_Sonderzeichen
{
    class ConvertString
    {
        
        public static string Convert(string text)
        {
            text = text.ToLower();
            
            string newText = "";
            foreach(char character in text)
            {
                if(character == 'ä')
                {
                    newText += "ae";
                }else if(character == 'ü')
                {
                    newText += "ue";
                }else if(character == 'ö')
                {
                    newText += "oe";
                }
                else
                {
                    newText += character;
                }
            }
            return newText;

        }
    }
}
