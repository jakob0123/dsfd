﻿using System;

namespace _2._1_Sonderzeichen
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(ConvertString.Convert("HÄllöü"));
        }
    }
}
